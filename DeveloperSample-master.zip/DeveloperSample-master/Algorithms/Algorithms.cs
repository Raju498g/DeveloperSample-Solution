using System;

namespace DeveloperSample.Algorithms
{
    public static class Algorithms
    {
        public static int GetFactorial(int n) => (n == 1 ? 1 : n * GetFactorial(n - 1));
            
        public static string FormatSeparators(params string[] items){
            switch (items.Length)
            {
                case 0: return "";
                case 1: return items[0];
                default: {
                    var items2 = new string[items.Length-1];
                    Array.Copy(items,items2,items.Length-1);
                    return string.Join(", ", items2) + " and " + items[items.Length-1];
                }   
            }
        }
    }
}