using System;

namespace DeveloperSample.Container
{
    public class Container
    {
        private Type _interfaceType;
        private Type _implementationType;
        public void Bind(Type interfaceType, Type implementationType)
        {

            _interfaceType = interfaceType;
            _implementationType = implementationType;

        }
        public T Get<T>()
        {
            if (typeof(T).Equals(_interfaceType)){
                return (T)Activator.CreateInstance(_implementationType);
            }
            
            throw new Exception("Has not been bounded!");
        }
    }
}