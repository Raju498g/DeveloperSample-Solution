import React, { useState } from "react";
import './App.css';
import LoginForm from './LoginForm';
import LoginAttemptList from './LoginAttemptList';

const App = () => {
  const [loginAttempts, setLoginAttempts] = useState([]);

  return (
    <div className="App">
      <LoginForm onSubmit={({ login, password }) => {
        let time = new Date();
        time = time.toLocaleDateString()+ " " + time.toLocaleTimeString();
        setLoginAttempts([...loginAttempts, { name: login.trim(), time: time}]);
        console.log("Login Attempted:", { login, password, loginAttempts });
      }} />
      <LoginAttemptList attempts={loginAttempts} />
    </div>
  );
};

export default App;
