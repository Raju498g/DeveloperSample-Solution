import React from "react";
import './LoginForm.css';

const LoginForm = (props) => {
	const handleSubmit = (event) =>{
		event.preventDefault();
		var { name, password } = document.forms[0]
		props.onSubmit({
			login: name.value,
			password: password.value,
		});
	}

	return (
		<form className="form" onSubmit={handleSubmit}>
			<h1>Login</h1>
			<label htmlFor="name">Name</label>
			<input type="text" id="name"/>
			<label htmlFor="password">Password</label>
			<input type="password" id="password" />
			<button type="submit">Continue</button>
		</form>
	)
}

export default LoginForm;