import React, { useState } from "react";
import "./LoginAttemptList.css";

const LoginAttempt = (props) => (<li {...props}> <strong>{props.children[0]} </strong>({props.children[1]})</li>)


const LoginAttemptList = (props) => {
	const [filterList, setFilterList] = useState([]);
	const filter_handler = (event) => {
		if (event.target.value)
			setFilterList(props.attempts.filter(data => data.name.startsWith(event.target.value)));
		else
			setFilterList([]);
	};
	return (
		<div className="Attempt-List-Main">
			<p>Recent activity</p>
			<input type="input" placeholder="Filter..." onInput={filter_handler} />
			<ul className="Attempt-List">
				{filterList.length > 0 ?
					filterList.map(data => <LoginAttempt>{data.name}{data.time}</LoginAttempt>) :
					props.attempts.map(data => <LoginAttempt>{data.name}{data.time}</LoginAttempt>)
				}
			</ul>
		</div>
	)
};

export default LoginAttemptList;