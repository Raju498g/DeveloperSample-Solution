using System;

namespace DeveloperSample.ClassRefactoring
{
    public abstract class Swallow
    {
        public SwallowType Type { get; }

        public SwallowLoad Load { get; private set; }

        public Swallow(SwallowType swallowType)
        {
            Type = swallowType;
        }

        public void ApplyLoad(SwallowLoad load)
        {
            Load = load;
        }

        public virtual double GetAirspeedVelocity()
        {
            throw new Exception();
        }
    }
    public class AfricanSwallow : Swallow
    {
        public AfricanSwallow() : base(SwallowType.African) { }

        public override double GetAirspeedVelocity() => (Load == SwallowLoad.None ? 22 : 18);
    }
    public class EuropeanSwallow : Swallow
    {
        public EuropeanSwallow() : base(SwallowType.European) { }

        public override double GetAirspeedVelocity() => (Load == SwallowLoad.None ? 20 : 16);

    }
}