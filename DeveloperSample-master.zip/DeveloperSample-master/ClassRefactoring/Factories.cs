namespace DeveloperSample.ClassRefactoring
{

    public class SwallowFactory
    {
        public Swallow GetSwallow(SwallowType swallowType)
        {
            if (swallowType == SwallowType.African)
                return new AfricanSwallow();
            else
                return new EuropeanSwallow();
        }

        public static SwallowFactory CreateInstance()
        {
            return new SwallowFactory();
        }
    }

}